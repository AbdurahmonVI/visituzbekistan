<?php 
	include 'php/config.php';

	if (!isset($_GET['tour_id'])) {
		echo 'Unaqa tur yoq';
	}

	$k = $_GET['tour_id'];

	$getsql = mysqli_query($connection, "SELECT * FROM multiple_tours WHERE ID = '$k' LIMIT 1");

	if (mysqli_num_rows($getsql) == 0) {
		echo 'Unaqa tur yoq';
	} else {
		print_r(mysqli_fetch_assoc($getsql));
	}

	mysqli_close($connection);
?>