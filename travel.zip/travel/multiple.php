<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" href="./favicon.ico" type="image/x-icon" />
    <title>VisitUzbekistan</title>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
      integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link rel="stylesheet" type="text/css" href="css/hotel_info.css" />
  </head>
  <body>
    <div class="hero" style="background-image: url(images/multiple/bukhara.jpg);">
      <h1 class="welcome-text">Tashkent to Bukhara</h1>
    </div>
    <div class="details">
      <div class="detail">
        Days
        <span class="detailed"><br /><b>10</b></span>
      </div>
      <div class="detail">
        Style
        <span class="detailed"><br /><b>Original</b></span>
      </div>
      <div class="detail">
        Rating <br />
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-solid fa-star"></i>
        <i class="fa-regular fa-star"></i>
      </div>
      <div class="detail">
        From
        <span class="detailed"><br /><b>$1000 USD</b></span>
      </div>
      <div class="detail">
        <a href="" class="detailed offer">Offer</a>
      </div>
    </div>
    <div class="text">
      <hr class="line" />
      <h1 class="title">Pulvinar mattis nunc sed blandit.</h1>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
        velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
        occaecat cupidatat non proident, sunt in culpa qui officia deserunt
        mollit anim id est laborum.
      </p>
      <hr class="line" />
      <table class="data">
        <tr>
          <th class="head_info">Start</th>
          <td class="data_info">Tashkent, Uzbekistan</td>
          <th class="head_info">Code</th>
          <td class="data_info">########</td>
        </tr>
        <tr>
          <th class="head_info">Finish</th>
          <td class="data_info">Bukhara, Uzbekistan</td>
          <th class="head_info">Physical rating</th>
          <td class="data_info">3</td>
        </tr>
        <tr>
          <th class="head_info">Destinations</th>
          <td class="data_info">Tashkent, Bukhara, Samarqand, Khiva</td>
          <th class="head_info">Ages</th>
          <td class="data_info">Min 15</td>
        </tr>
        <tr>
          <th class="head_info">Style</th>
          <td class="data_info">Original</td>
          <th class="head_info">Group size</th>
          <td class="data_info">Min 2, Max 12</td>
        </tr>
        <tr>
          <th class="head_info">Theme</th>
          <td class="data_info">Explorer</td>
        </tr>
      </table>
      <hr class="line" />
      <h1 class="title" style="text-align: left">
        What you will love this trip
      </h1>
      <ul class="like">
        <li class="like_data">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempure dolor in reprehenderit in voluptate velit esse cillum
          dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
          proident, sunt in culpa qui officia deserunt mollit anim id est
          laborum.
        </li>
        <li class="like_data">
          Lore cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
          cupidatat non proident, sunt in culpa qui officia deserunt mollit anim
          id est laborum.
        </li>
        <li class="like_data">
          Iui officia deserunt mollit anim id est laborum.
        </li>
        <li class="like_data">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </li>
      </ul>
      <h1 class="title" style="text-align: left">
        Is this trip right for you?
      </h1>
      <ul class="like">
        <li class="like_data">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempure dolor in reprehenderit in voluptate velit esse cillum
          dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum. proident, sunt
          in culpa qui officia deserunt mollit anim id est laborum.
        </li>
        <li class="like_data">
          Lore cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
          cupidatat non proident, sunt in culpa qui officia deserunt mollit anim
          id est laborum.
        </li>
        <li class="like_data">
          Iu Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum. i officia
          deserunt mollit anim id est laborum.
        </li>
        <li class="like_data">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </li>
      </ul>
      <div id="demo" class="carousel slide" data-bs-ride="carousel">
        <h1 class="title" style="text-align: left">Gallery</h1>
        <div class="carousel-indicators">
          <button
            type="button"
            data-bs-target="#demo"
            data-bs-slide-to="0"
            class="active"
          ></button>
          <button
            type="button"
            data-bs-target="#demo"
            data-bs-slide-to="1"
          ></button>
          <button
            type="button"
            data-bs-target="#demo"
            data-bs-slide-to="2"
          ></button>
        </div>

        <div class="carousel-inner">
          <div class="carousel-item active">
            <img
              src="./images/multiple/Tashkent.jpg"
              alt="Tashkent"
              class="d-block w-100"
            />
          </div>
          <div class="carousel-item">
            <img
              src="./images/multiple/Tashkent2.jpg"
              alt="Tashkent"
              class="d-block w-100"
            />
          </div>
          <div class="carousel-item">
            <img src="./images/multiple/bukhara2.jpg" alt="Bukhara" class="d-block w-100" />
          </div>
        </div>

        <button
          class="carousel-control-prev"
          type="button"
          data-bs-target="#demo"
          data-bs-slide="prev"
        >
          <span class="carousel-control-prev-icon"></span>
        </button>
        <button
          class="carousel-control-next"
          type="button"
          data-bs-target="#demo"
          data-bs-slide="next"
        >
          <span class="carousel-control-next-icon"></span>
        </button>
      </div>
      <div class="city_details">
        <h1 class="title" style="text-align: left">Itinerary</h1>
        <details class="cities">
          <summary class="city_name">Tashkent</summary>
          <p class="city_info">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
            ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
            aliquip ex ea commodo consequat. Duis aute irure dolor in
            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
            pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
            culpa qui officia deserunt mollit anim id est laborum.
          </p>
        </details>
        <details class="cities">
          <summary class="city_name">Samarkand</summary>
          <p class="city_info">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
            ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
            aliquip ex ea commodo consequat. Duis aute irure dolor in
            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
            pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
            culpa qui officia deserunt mollit anim id est laborum.
          </p>
        </details>
        <details class="cities">
          <summary class="city_name">Khiva</summary>
          <p class="city_info">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
            ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
            aliquip ex ea commodo consequat. Duis aute irure dolor in
            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
            pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
            culpa qui officia deserunt mollit anim id est laborum.
          </p>
        </details>
        <details class="cities">
          <summary class="city_name">Bukhara</summary>
          <p class="city_info">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
            ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
            aliquip ex ea commodo consequat. Duis aute irure dolor in
            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
            pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
            culpa qui officia deserunt mollit anim id est laborum.
          </p>
        </details>
      </div>
      <div class="inclusions">
        <table class="inclusion" style="margin-top: 50px">
          <tr>
            <th class="inclusion_name">
              <i class="fa-solid fa-burger" style="font-size: 50pt"></i>
            </th>
            <td class="inclusion_data">
              <h1
                class="title"
                style="text-align: left; font-size: 20pt; margin: 10px 0"
              >
                Meals
              </h1>
              9 breakfasts, 1 lunch, 1 dinner
            </td>
            <th class="inclusion_name">
              <i class="fa-solid fa-bed" style="font-size: 50pt"></i>
            </th>
            <td class="inclusion_data">
              <h1
                class="title"
                style="text-align: left; font-size: 20pt; margin: 10px 0"
              >
                Accomodation
              </h1>
              Hotel (8 nights), Camping (1 night)
            </td>
          </tr>
          <tr>
            <th class="inclusion_name">
              <i class="fa-solid fa-camera" style="font-size: 50pt"></i>
            </th>
            <td class="inclusion_data">
              <h1
                class="title"
                style="text-align: left; font-size: 20pt; margin: 10px 0"
              >
                Included activities
              </h1>
              <ul class="like">
                <li class="like_data">Lorem ipsum dolor sit amet.</li>
                <li class="like_data">Lorem ipsum dolor sit amet.</li>
                <li class="like_data">Lorem ipsum dolor sit amet.</li>
                <li class="like_data">Lorem ipsum dolor sit amet.</li>
                <li class="like_data">Lorem ipsum dolor sit amet.</li>
                <li class="like_data">Lorem ipsum dolor sit amet.</li>
              </ul>
            </td>
            <th class="inclusion_name">
              <i class="fa-solid fa-bus" style="font-size: 50pt"></i>
            </th>
            <td class="inclusion_data">
              <h1
                class="title"
                style="text-align: left; font-size: 20pt; margin: 10px 0"
              >
                Transport
              </h1>
              Private vehicle, 4x4 vehicle, Plane, Metro, Taxi
            </td>
          </tr>
        </table>
      </div>
    </div>
    <div class="end">
      <div class="rowman" id="top">
        <a href="#"><i class="fa-brands fa-instagram"></i></a>
        <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
        <a href="#"><i class="fa-brands fa-twitter"></i></a>
        <a href="#"><i class="fa-brands fa-youtube"></i></a>
      </div>
      <div class="rowman">
        <p>Copyright ©️ 2022 VisitUzbekistan. All Rights Reserved TGA</p>
      </div>
      <div class="rowman">
        <p><a href="#" id="cook">Privacy Policy</a></p>
        <p>|</p>
        <p><a href="#" id="cook">Cookie Policy</a></p>
      </div>
    </div>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
      integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
