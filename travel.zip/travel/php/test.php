<?php 
	include 'config.php';
	session_start();

	mysqli_query($connection, "UPDATE events SET seats_left = seats_left - 1 WHERE ID = ".$_SESSION['checked_options']['existed_dates']."");
 ?>