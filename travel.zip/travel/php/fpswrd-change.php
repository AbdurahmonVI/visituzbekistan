<?php 
	include "filterString.php";
	include "config.php";

	$login = filterString($connection, $_POST['login']);
	$password = filterString($connection, $_POST['password']);

	$query = mysqli_query($connection, "SELECT * FROM `fpswrd` WHERE email = '{$login}' AND checked = 1 LIMIT 1");

	if (mysqli_num_rows($query) == 1) {
		$new_password = md5($password);
		$info = mysqli_fetch_assoc($query);
		$query1 = mysqli_query($connection, "UPDATE `users` SET password = '{$new_password}' WHERE email = '{$info["email"]}'");

		if ($query1) {
			mysqli_query($connection, "DELETE FROM fpswrd WHERE ID = {$info['ID']}");
			echo 'success';
		}
		else {
			echo 'Oh something wrong. Try again later';
		}
	} else {
		echo 'Your email is not founded';
	}
 ?>