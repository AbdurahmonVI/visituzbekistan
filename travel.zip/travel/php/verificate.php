<?php 
	include "config.php";

	$code = $_GET['code'];

	$query = mysqli_query($connection, "SELECT ID FROM mail WHERE code = '{$code}' AND checked = 0 LIMIT 1");

	if (mysqli_num_rows($query) == 1) {
		$info = mysqli_fetch_assoc($query);
		mysqli_query($connection, "UPDATE `mail` SET checked = 1 WHERE ID = '{$info['ID']}'");
		echo "You can close your window and return";
	} else echo "Not correct";
 ?>