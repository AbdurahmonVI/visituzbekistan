<?php 
	$connection = mysqli_connect("localhost", "root", "", "visituzbekistan");
	if (!$connection) echo "Database connected". mysqli_connect_error();
 ?>