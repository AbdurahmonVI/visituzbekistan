<?php 
	include 'filterString.php';
	include 'config.php';

	$login = filterString($connection, $_POST['login']);

	$query = mysqli_query($connection, "SELECT * FROM users WHERE email = '{$login}'  LIMIT 1");
	if (mysqli_num_rows($query) == 1) {
		$query2 = mysqli_query($connection, "SELECT ID FROM fpswrd WHERE email = '{$login}' LIMIT 1");
		if (mysqli_num_rows($query2) == 0) {
			$code = uniqid();
			$user = mysqli_fetch_assoc($query);
			mail($login, "Code to change your password", "<h1>Hello ". $user['firstname']." ".  $user['lastname'].".</h1><br> Here's your code to change your password $code", "Content-Type: text/html; charset=ISO-8859-1\r\n");

			$query = mysqli_query($connection, "INSERT INTO `fpswrd` (`code`, `email`) VALUES ('{$code}', '{$login}')");

			if ($query)
				echo "success";
			else echo "Oh something wrong. Please try again later";
		} else {
			echo "Verification code has already send";
		}
		

	} else 
		echo "$login - this email not founded";
 ?>