<?php 
	include "config.php";
	session_start();

	$uniq_id = $_POST['uniq_id'];

	$query = mysqli_query($connection, "SELECT ID FROM mail WHERE code = '{$uniq_id}' AND checked = 1");

	if (mysqli_num_rows($query) == 1) {
		$names = ['firstname', 'lastname', 'mobile_number', 'nickname', 'email', 'password'];

		$file = $_FILES['file'];

		for ($i = 0; $i < count($names); $i++) { 
			$active = $names[$i];
			${$active} = $_POST[$active];
		}

		if ($file['error'] == 4 && strlen($file['tmp_name']) == 0) {
			$file_name = "user.png";
		} else {
			$file_name = time()."".basename($file["name"]);
			if (!move_uploaded_file($file["tmp_name"], "../users_img/". $file_name)) {
				echo "Sorry, there was an error uploading your file."; exit;
			}
		}	

		$password = md5($password);

		$query1 = mysqli_query($connection, "INSERT INTO `users`(`uniq_id`, `firstname`, `lastname`, `mobile_number`, `email`, `nickname`, `password`, `img`) VALUES ('{$uniq_id}','{$firstname}','{$lastname}','{$mobile_number}','{$email}', '{$nickname}','{$password}','{$file_name}')");

		if ($query1) {
			$idIn_mail = mysqli_fetch_assoc($query)['ID'];
			mysqli_query($connection, "DELETE FROM `mail` WHERE ID = {$idIn_mail}");
			$_SESSION['uniq_id'] = $uniq_id;
			echo "success";
		} else
			echo "Please try again later";
	} else
		echo "false";
 ?>