<?php 
	function filterString ($connection, $str) {
		if (empty($str)) {
			echo "All inputs are required!";
			exit;
		}
		return mysqli_real_escape_string($connection, filter_var($str, FILTER_SANITIZE_STRING));
	}
 ?>