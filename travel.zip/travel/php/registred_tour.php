<?php 
	session_start();
	include 'config.php';

	function backecho ($query, $connection, $uniqid) {
		if ($query) {
			return $query;
		} else {
			mysqli_query($connection, "DELETE FROM registred_tours WHERE uniq_id = '".$uniqid."'");
			echo 'Server Error. Please try again'; exit;
		}
	}

	if (isset($_POST['09xbhjut2'])) {
		if ($_POST['09xbhjut2'] == "zza45kaja5672" and isset($_SESSION['checked_options']['type'])) {
			if ($_SESSION['checked_options']['type'] == "Group" and count($_SESSION['checked_options']) == 5) {
				$uniqid = uniqid();
				$query = mysqli_query($connection, "INSERT INTO  `registred_tours` (`ID`, `uniq_id`, `tour_id`, `type`, `date`, `number_people`, `price`, `car_type_id`, `Location_from`, `user_id`) VALUES (NULL, '".$uniqid."', '".$_SESSION['tour_species']['ID']."', '".$_SESSION['checked_options']['type']."', '".$_SESSION['tour_species']['event'][0]."', '".serialize([$_SESSION['checked_options']['adults'], $_SESSION['checked_options']['kids']])."', '".$_SESSION['tour_species']['event'][3]."', '".$_SESSION['tour_species']['event'][1]."', '".$_SESSION['tour_species']['event'][2]."', '".$_SESSION['uniq_id']."')");

				if ($query) {
					$x = mysqli_fetch_assoc(backecho(mysqli_query($connection, "SELECT seats_left FROM events WHERE ID = ".$_SESSION['checked_options']['existed_dates']." LIMIT 1"), $connection, $uniqid));
					if ($x['seats_left'] < $_SESSION['checked_options']['people']) {
						backecho(mysqli_query($connection, "DELETE FROM registred_tours WHERE uniq_id = '".$uniqid."'"), $connection, $uniqid);
						echo 'Sorry. No seats left';
					}

					mysqli_query($connection, "UPDATE events SET seats_left = seats_left - ".$_SESSION['checked_options']['people']." WHERE ID = ".$_SESSION['checked_options']['existed_dates']."");

					unset($_SESSION['tour_species']);
					unset($_SESSION['checked_options']);
					echo 'success'; exit;
				} else {
					echo 'Server Error. Please try again'; exit;
				}
			} elseif ($_SESSION['checked_options']['type'] == "Individual" and count($_SESSION['checked_options']) == 8) {
				$uniqid = uniqid();
				$query = mysqli_query($connection, "INSERT INTO  `registred_tours` (`ID`, `uniq_id`, `tour_id`, `type`, `date`, `number_people`, `price`, `car_type_id`, `Location_from`, `user_id`) VALUES (NULL, '".$uniqid."', '".$_SESSION['tour_species']['ID']."', '".$_SESSION['checked_options']['type']."', '".$_SESSION['checked_options']['datetime']."', '".serialize([$_SESSION['checked_options']['adults'], $_SESSION['checked_options']['kids']])."', '".$_SESSION['tour_species']['event'][0]."', '".$_SESSION['checked_options']['car_type']."', '".$_SESSION['checked_options']['location']."', '".$_SESSION['uniq_id']."')");

					if ($query) {
						// $x = mysqli_fetch_assoc(backecho(mysqli_query($connection, "SELECT seats_left FROM events WHERE ID = ".$_SESSION['checked_options']['existed_dates']." LIMIT 1"), $connection, $uniqid));
						// if ($x['seats_left'] < $_SESSION['checked_options']['people']) {
						// 	backecho(mysqli_query($connection, "DELETE FROM registred_tours WHERE uniq_id = '".$uniqid."'"), $connection, $uniqid);
						// 	echo 'Sorry. No seats left';
						// }

						if ($_SESSION['tour_species']['strict_timing'][0] == "a") {
							$time = new DateTime($_SESSION['checked_options']['datetime']);
							$time->add(new DateInterval('PT'.$_SESSION['tour_species']['approx_duration'].'M'));
							backecho(mysqli_query($connection, "INSERT INTO `car_deilivers` (`ID`, `location_start`, `location_mid`, `location_finish`, `taking_date`, `car_id`, `take_guide`, `rgtour_uniq_id`, `tour_id`, `take_money`) VALUES (NULL, '".$_SESSION['checked_options']['location']."', '".$_SESSION['tour_species']['location_text']."', 'Nowhere', '".$_SESSION['checked_options']['datetime']."', ".$_SESSION['checked_options']['car_type'].", 0, '".$uniqid."', ".$_SESSION['tour_species']['ID'].", 1)"), $connection, $uniqid);
							backecho(mysqli_query($connection, "INSERT INTO `car_deilivers` (`ID`, `location_start`, `location_mid`, `location_finish`, `taking_date`, `car_id`, `take_guide`, `rgtour_uniq_id`, `tour_id`, `take_money`) VALUES (NULL, '".$_SESSION['tour_species']['location_text']."', '".$_SESSION['checked_options']['location']."', 'Nowhere', '".$time->format('Y-m-d H:i')."', ".$_SESSION['checked_options']['car_type'].", 0, '".$uniqid."', ".$_SESSION['tour_species']['ID'].", 0)"), $connection, $uniqid);
								//// You can convert locations to latidudes
						} else {
							backecho(mysqli_query($connection, "INSERT INTO `car_deilivers` (`ID`, `location_start`, `location_mid`, `location_finish`, `taking_date`, `car_id`, `take_guide`, `rgtour_uniq_id`, `tour_id`) VALUES (NULL, '".$_SESSION['checked_options']['location']."', '".$_SESSION['tour_species']['location_text']."', '".$_SESSION['checked_options']['location']."', '".$_SESSION['checked_options']['datetime']."', '".$_SESSION['checked_options']['car_type']."', 1, '".$uniqid."', ".$_SESSION['tour_species']['ID'].")"), $connection, $uniqid);
								//// You can convert locations to latidudes
						}



						unset($_SESSION['tour_species']);
						unset($_SESSION['checked_options']);
						echo 'success'; exit;
					} else {
						echo 'Server Error. Please try again'; exit;
					}
			} else {
				if (isset($_SESSION['tour_species']['ID'])) {
					echo 'f../singletour/type.php?tour_id='.$_SESSION['tour_species']['ID']; exit;
				} else {
					echo 'f../homepage.php'; exit;
				}
			}
		} else {
			echo 'f../homepage.php'; exit;
		}
	} else {
		echo 'f../homepage.php'; exit;
	}
 ?>