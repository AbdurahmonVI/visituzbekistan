<?php 
	include "filterString.php";
	include "config.php";

	$login = filterString($connection, $_POST['login']);
	$code = filterString($connection, $_POST['code']);

	$query = mysqli_query($connection, "SELECT * FROM fpswrd WHERE email = '{$login}' AND checked = 0 LIMIT 1");

	if (mysqli_num_rows($query) == 0) {
		echo "Your email is not founded";
	} else {
		$info = mysqli_fetch_assoc($query);
		if ($code == $info['code']) {
			$id = $info['ID'];
			$query = mysqli_query($connection, "UPDATE `fpswrd` SET checked = 1 WHERE ID = '{$id}'");
			echo 'success';
		} else {
			echo 'Your verification code is not correct';
		}
	}
 ?>