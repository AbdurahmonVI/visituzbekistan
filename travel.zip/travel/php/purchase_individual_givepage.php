<?php 
	function render ($number) {
		switch ($number) {
			case "type":
				return '<div class="section">
				Type: <br>
				<input type="radio" name="type" value="Group" required>Group <input type="radio" name="type" value="Individual" required>Individual <br>
				<input type="hidden" name="zkkaja">
				<button type="submit">Next</div>
			</div>';
			case "location":
				return '<div class="section">
					Location:
					<input type="text" name="location" required>
					<input type="hidden" name="zkkaja">
					<button type="submit">Next</div>
				</div>';
			break;
			case "number_of_people":
				return '<div class="section">
					Number of people: <br>
					Adults: <input type="number" name="adults" value="0">
					Kids: <input type="number" name="kids" value="0">
					<input type="hidden" name="zkkaja">
					<button type="submit">Next</div>
				</div>';
			break;
			case "car_type":
				return '<div class="section">
					Car type: <br>
					<input type="radio" name="car_type" value="2"> Gentra
					<input type="radio" name="car_type" value="4"> Malibu
					<input type="radio" name="car_type" value="8"> Cobalt
					<input type="hidden" name="zkkaja">
					<button type="submit">Next</div>
				</div>';
			break;
			case "input_date":
				return '<div class="section">
					Input date: <br>
					DateTime: <input type="date" name="date">
					Time: <input type="time" name="time">
					<input type="hidden" name="zkkaja">
					<button type="submit">Next</div>
				</div>';
			break;
			case "existed_dates":
				return '<div class="section">
					Existed Dates: <br>
					<input type="radio" name="existed_dates" value="4"> May 5 14:00; 2 seats Left <br>
					<input type="radio" name="existed_dates" value="4"> April 12 17:00; 2 seats Left <br>
					<input type="radio" name="existed_dates" value="4"> September 23 14:00; 2 seats Left <br>
					<input type="hidden" name="zkkaja">
					<button type="submit">Next</div>
				</div>';
			break;
			case "comments":
				return '<div class="section">
					Demands: <br>
					<textarea name="comments" id="" cols="30" rows="10" placeholder="Write your demands.."></textarea>
					<input type="hidden" name="zkkaja">
					<button type="submit">Next</div>
				</div>';
			break;
		}
	}


	/* 

		'<div class="section">
					Input date (strict timing): <br>
					Date: <input type="date" name="date">
					Time: 
					<input type="radio" name="time" value="1"> 8:00
					<input type="radio" name="time" value="2"> 17:00
					<input type="radio" name="time" value="3"> 20:00
		</div>'
		 */
 ?>