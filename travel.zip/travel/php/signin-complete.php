<?php 
	include "config.php";
	session_start();

	include "filterString.php";

	$login = filterString($connection, $_POST['login']);
	$password = md5(filterString($connection, $_POST['password']));

	$query = mysqli_query($connection, "SELECT uniq_id FROM users WHERE (nickname = '{$login}' OR email = '{$login}') AND password = '{$password}' LIMIT 1");

	if (mysqli_num_rows($query) == 1) {
		$_SESSION['uniq_id'] = mysqli_fetch_assoc($query)["uniq_id"];
		echo "success";
	} else
		echo "Login or password are incorrect";
 ?>