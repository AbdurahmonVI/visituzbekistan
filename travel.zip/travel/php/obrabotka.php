<?php 
	session_start();
	include 'config.php';

	if (isset($_SESSION['uniq_id'])) {
		$sql = mysqli_query($connection, "SELECT * FROM users WHERE uniq_id = '{$_SESSION['uniq_id']}' LIMIT 1");
		if (mysqli_num_rows($sql) == 1) {
			$_SESSION['user'] = mysqli_fetch_assoc($sql);
			header("Location: ../homepage.php");
		} else {
			header("Location: ../signin.php");
		}
	} else {
		header("Location: ../signin.php");
	}
?>