<?php 
	include "config.php";
	session_start();

	include "filterString.php";

	$names = ['firstname', 'lastname', 'mobile_number', 'nickname', 'email', 'password'];

	for ($i = 0; $i < count($names); $i++) { 
		$active = $names[$i];
		${$active} = filterString($connection, $_POST[$active]);
		$len = strlen(${$active});
		if ($len < 4) {
			echo ucfirst($active)." is too short"; exit;
		} else if ($len > 70) {
			echo ucfirst($active)." is too long"; exit;
		}
	}

	function isValidTelephoneNumber(string $telephone, int $minDigits = 9, int $maxDigits = 14): bool {
	    if (preg_match('/^[+][0-9]/', $telephone)) { //is the first character + followed by a digit
	        $count = 1;
	        $telephone = str_replace(['+'], '', $telephone, $count);
	    }
	    $telephone = str_replace([' ', '.', '-', '(', ')'], '', $telephone); 
	    return preg_match('/^[0-9]{'.$minDigits.','.$maxDigits.'}\z/', $telephone);
	}

	if (!isValidTelephoneNumber($mobile_number)) {
	    $mobile_number = str_replace([' ', '.', '-', '(', ')'], '', $mobile_number);
	}

	if (preg_match('~[0-9]+~', $firstname)) {
    	echo "First name mustn't have a number"; exit;
	} else if (preg_match('~[0-9]+~', $lastname)) {
		echo "Last name mustn't have a number"; exit;
	}

	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		echo "Your email is not valid"; exit;
	}

	if ($nickname[0] != "@") {
		echo 'Nickname must start with @'; exit;
	}

	$query = mysqli_query($connection, "SELECT ID FROM users WHERE nickname = '{$nickname}' LIMIT 1");

	if (mysqli_num_rows($query) == 1) {
		echo "$nickname nickname has already exist"; exit;
	}

	$query2 = mysqli_query($connection, "SELECT ID FROM users WHERE email = '{$email}' LIMIT 1");

	if (mysqli_num_rows($query2) == 1) {
		echo "$email email has already exist"; exit;
	}



	function checkImg ($file) {
	    $check = getimagesize($file["tmp_name"]);
	    if (!$check) {
	  		echo "File is not an image."; exit;
	    }

	    if ($file["size"] > 500000) {
			  echo "Sorry, your file is too large."; exit;
		}

		$type = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));

		if (!($type == "jpg" || $type == "png" || $type == "jpeg" || $type == "webp" || $type == "gif")) {
		  echo "Sorry, only JPG, JPEG, PNG, GIF, WEBP files are allowed."; exit;
		}

		return true;
	}

	if (mysqli_num_rows(mysqli_query($connection, "SELECT ID FROM mail WHERE email = '{$email}' LIMIT 1")) > 0) {
		echo "Your verification link has already sended"; exit;
	}	

	$file = $_FILES['file'];

	if (!($file['error'] == 4 && strlen($file['tmp_name']) == 0)) {
		checkImg($file);
	}

	$uniq_id = uniqid();

	mail($email, "Verification link", "<a href='localhost/travel/php/verificate.php?code=".$uniq_id."'>Click me</a>", "Content-Type: text/html; charset=ISO-8859-1\r\n");
	$query = mysqli_query($connection, "INSERT INTO `mail`(`code`, `email`) VALUES ('{$uniq_id}', '{$email}')");

	echo $uniq_id;
 ?>