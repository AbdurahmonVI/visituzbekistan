<?php include "layouts/sign-head.php"; ?>
<style type="text/css">
	div.block input {width: 100%}	
	.container {width: 500px}
	div.block {height: 230px}
	div.field>i {right: 10px}
</style>
<form class="container df" id="form" action="#" enctype="multipart/form-data">
	<h1>SignIn <i class="fas fa-spinner"></i></h1>
		<div class="error df"></div>
	<div class="contain df">
		<div class="block df">
			<div class="field df">
				<label for="login">Login</label>
				<input type="text" id="login" name="login" placeholder="Enter your email or nickname" required="required">
			</div>
			<div class="field df">
				<label for="password">Password </label>
				<input type="password" id="password" name="password" placeholder="Password..." required="required">
				<i class="fas fa-eye"></i>
			</div>
		</div>
	</div>
	<button type="submit">SignIn</button>
	<p class="link">
		Don't have an account yet? <a href="signup.php">Sign Up</a><br><br>
		Forgot your password? <a href="password.php?type=start">Find it</a>
	</p>
</form>
<script src="javascript/pass-show-hide.js"></script>
<script src="javascript/signin-ajax.js"></script>
</body>
</html>