<?php include "layouts/sign-head.php"; ?>
<form class="container df" id="form" action="#" enctype="multipart/form-data">
	<h1>SignUp <i class="fas fa-spinner"></i></h1>
	<div class="error df"></div>
	<div class="contain df">
		<div class="block df" style="height: 450px;">
			<div class="field df">
				<label for="fname">First name </label>
				<input type="text" id="fname" name="firstname" placeholder="Enter your first name..." required="required">
			</div>
			<div class="field df">
				<label for="lname">Last name </label>
				<input type="text" id="lname" name="lastname" placeholder="Enter your last name..." required="required">
			</div>
			<div class="field df">
				<label for="nickname">Nickname </label>
				<input type="text" id="nickname" name="nickname" placeholder="Enter your nickname.." required="required">
			</div>
			<div class="field df">
				<label for="password">Password </label>
				<input type="password" id="password" name="password" placeholder="Password..." required="required">
				<i class="fas fa-eye"></i>
			</div>
		</div>
		<div class="block df" style="height: 450px;">
			<div class="field df">
				<label for="mnum">Mobile number </label>
				<input type="text" id="mnum" name="mobile_number" placeholder="Enter your mobile number...">
			</div>
			<div class="field df">
				<label for="file">Choose your image (Optional)</label>
				<input type="file" id="file" name="file" accept="image/png, image/jpeg, image/webp, image/jpg">
			</div>
			<div class="field df">
				<label for="email">Email</label>
				<input type="email" id="email" name="email" placeholder="Enter your email" required="required">
			</div>
		</div>
	</div>
	<button type="submit">Send</button>
	<p class="link">Have an account? <a href="signin.php">Sign In</a></p>
</form>
<script src="javascript/pass-show-hide.js"></script>
<script src="javascript/signup-ajax.js"></script>
</body>
</html>