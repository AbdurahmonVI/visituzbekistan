<?php include "layouts/sign-head.php"; ?>
<style type="text/css">
	div.block input {width: 100%}	
	.container {width: 500px}
	div.block {height: 150px}
	div.field>i {right: 10px}
	button {margin-top: 8px}
</style>

<form class="container df" id="form" action="#" enctype="multipart/form-data">
		<h1>Change Password <i class="fas fa-spinner"></i></h1>
		<div class="error df"></div>
		<div class="contain df">
			<div class="block df">
				<div class="field df">

<?php if (isset($_GET['type'])): ?>
	<?php if ($_GET['type'] == "start"): ?>
		<input type="hidden" id="get" value="1">
		<label for="login">Email</label>
		<input type="text" id="login" name="login" placeholder="Enter your email" required="required">
		</div>
	<?php elseif ($_GET['type'] == "code"): ?>
		<input type="hidden" id="get" value="2">
		<label for="code">Verification code</label>
		<input type="text" id="code" name="code" placeholder="Enter your verification code" required="required">
		<input type="hidden" name="email" value="<?=$_GET['email']?>">
		</div>
		<p style="margin-bottom: 0;">We have send the verification code your email</p>
	<?php elseif ($_GET['type'] == "chpswrd"): ?>
		<input type="hidden" id="get" value="3">
		<label for="password">New Password</label>
		<input type="password" id="password" name="password" placeholder="Enter your new password" required="required">
		<i class="fas fa-eye"></i>
		</div>
		<p style="margin-bottom: 0;">We wish that you won't forgot your new password</p>
		<script src="javascript/pass-show-hide.js"></script>
	<?php endif ?>
<?php endif ?>

		</div>
	</div>
	<button type="submit">Send</button>
</form>
<script src="javascript/fpswrd-ajax.js"></script>
</body>
</html>