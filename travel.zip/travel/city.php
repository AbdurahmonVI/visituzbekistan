<?php 
	include 'php/config.php';

	$city = isset($_GET['city']) ? $_GET['city'] : 'Tashkent';

	$getsql = mysqli_query($connection, "SELECT * FROM cities WHERE City = '$city' LIMIT 1");

	if (mysqli_num_rows($getsql) == 0) {
		echo 'Unaqa shahar yoq';
	} else {	
		print_r(mysqli_fetch_assoc($getsql));
	}

	mysqli_close($connection);
?>