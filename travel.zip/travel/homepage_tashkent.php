<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
      integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  />
    <link rel="stylesheet" href="css/homepage_main.css" />
    <link rel="shortcut icon" href="./favicon.ico" type="image/x-icon">
    <title>𝐕𝐢𝐬𝐢𝐭𝐔𝐳𝐛𝐞𝐤𝐢𝐬𝐭𝐚𝐧.𝐮𝐳</title>
  </head>
  <body>
    <i class="fa-solid fa-ellipsis" id="stick"></i>

    <div class="slideman" id="right">
      <p>Samarkand</p>
      <i class="fa-solid fa-right-long"></i>
    </div>
    <div class="slideman" id="left">
      <i class="fa-solid fa-left-long"></i>
      <p>Bukhara</p>
    </div>
    <header class="bg3" id="head">
      <a href="#first"
        ><h1 data-aos="fade-up" data-aos-duration="1000">Tashkent</h1></a
      >
      <i class="fa-solid fa-plus"></i>
    </header>
    <section class="bg3" id="first">
      <div class="content">
        <h2 id="big" data-aos="fade-down">see</h2>
        <h2 data-aos="fade-down" data-aos-delay="100">Tashkent</h2>
        <p id="text" data-aos="fade-down" data-aos-delay="200">
          Every light in this city means a different story. Imagine yourself
          witnessing each of them in the heart of two continents. This city will
          look into your soul directly and make your experiences timeless.
        </p>
        <a href="see.html#article1"><button data-aos="zoom-in-down" data-aos-delay="300">See More</button></a>
      </div>
    </section>
    <section class="bg3" id="second">
      <div class="content">
        <h2 id="big" data-aos="fade-down">taste</h2>
        <h2 data-aos="fade-down" data-aos-delay="100">Tashkent</h2>
        <p id="text" data-aos="fade-down" data-aos-delay="200">
          Tashkent is waiting for you with its unique tastes from bitter to
          sweet, sour to salty. Aside from its enchanting historical beauty,
          Tashkent is the right address even just to try new flavours!
        </p>
        <button data-aos="zoom-in-down" data-aos-delay="300">See More</button>
      </div>
    </section>
    <section class="bg3" id="third">
      <div class="content">
        <h2 id="big" data-aos="fade-down">smell</h2>
        <h2 data-aos="fade-down" data-aos-delay="100">Tashkent</h2>
        <p id="text" data-aos="fade-down" data-aos-delay="200">
          The past, the present and the future full of surprises give this city
          its fragrance. You will find your childhood in a flower, the
          excitement of the future in a delicious meal, and the beauty of today
          in the unique scent of the forest, sea and streets in Tashkent.
        </p>
        <button data-aos="zoom-in-down" data-aos-delay="300">See More</button>
      </div>
    </section>
    <section class="bg3" id="fourth">
      <div class="content">
        <h2 id="big" data-aos="fade-down">touch</h2>
        <h2 data-aos="fade-down" data-aos-delay="100">Tashkent</h2>
        <p id="text" data-aos="fade-down" data-aos-delay="200">
          Feel the texture of Tashkent in the details of an antique building, in
          the soft fur of a stray cat, in a tulip that fascinates with its
          color, or in an authentic silk fabric. Tashkent will touch you as you
          stroll through the streets of this city.
        </p>
        <button data-aos="zoom-in-down" data-aos-delay="300">See More</button>
      </div>
    </section>
    <section class="bg3" id="fifth">
      <div class="content">
        <h2 id="big" data-aos="fade-down">listen</h2>
        <h2 data-aos="fade-down" data-aos-delay="100">Tashkent</h2>
        <p id="text" data-aos="fade-down" data-aos-delay="200">
          Listen to the heartbeats of two continents! If Tashkent was a playlist
          it would play in shuffle.
        </p>
        <button data-aos="zoom-in-down" data-aos-delay="300">See More</button>
      </div>
    </section>
    <section class="bg3" id="sixth">
      <div class="content">
        <h2 id="big" data-aos="fade-down">routes</h2>
        <h2 data-aos="fade-down" data-aos-delay="100">Tashkent</h2>
        <p id="text" data-aos="fade-down" data-aos-delay="200">
          Every light in this city means a different story. Imagine yourself
          witnessing each of them in the heart of two continents. This city will
          look into your soul directly and make your experiences timeless.
        </p>
        <button data-aos="zoom-in-down" data-aos-delay="300">See More</button>
      </div>
    </section>
    <section class="bg3" id="seventh">
      <div class="content">
        <h2 id="big" data-aos="fade-down">10 vibes from Tashkent</h2>
        <h2 data-aos="fade-down" data-aos-delay="100">Tashkent</h2>
        <p id="text" data-aos="fade-down" data-aos-delay="200">
          With its reservoirs that supplied İstanbul with water for many
          centuries after its foundation, its fountains, and rich fauna, today,
          Belgrad Forest serves as the city’s lungs. Roughly half an hour’s
          drive from the city center, Belgrad Forest’s running and cycling
          tracks make it a matchless destination for sports enthusiasts.
        </p>
        <button data-aos="zoom-in-down" data-aos-delay="300">See More</button>
      </div>
    </section>
    <section class="bg3" id="eighth">
      <div class="content">
        <h2 id="big" data-aos="fade-down">48 hours</h2>
        <h2 data-aos="fade-down" data-aos-delay="100">in Tashkent</h2>
        <p id="text" data-aos="fade-down" data-aos-delay="200">
          Straddling the Bosphorus Strait Asia, Tashkent is etched with
          thousands of years of history, bearing the marks of the Ancient
          Greeks, the Persians, the Romans, the Byzantines, the Uzbeks, and the
          Silk Road traders who've lived here over the centuries.
        </p>
        <button data-aos="zoom-in-down" data-aos-delay="300">See More</button>
      </div>
    </section>
    <div class="cards">
      <h2 id="cart">Multiple <span>Tours</span></h2>
      <div class="row carder" id="row1">
        <div class="card" id="first1">
          <p id="text2">Golf</p>
          <h3>Yunusabad</h3>
          <h4>Offer</h4>
          <a href=""><h4 class="h42"><a href="multiple.html">About</a></h4>
        </div>
        <div class="card" id="first2">
          <p id="text2">Camping</p>
          <h3>Yashnabad</h3>
          <h4>Offer</h4>
          <a href=""><h4 class="h42"><a href="multiple.html">About</a></h4>
        </div>
        <div class="card" id="first3">
          <p id="text2">Shopping</p>
          <h3>Uchtepa</h3>
          <h4>Offer</h4>
          <a href=""><h4 class="h42"><a href="multiple.html">About</a></h4>
        </div>
        <div class="card" id="first4">
          <p id="text2">Football</p>
          <h3>Chilanzar</h3>
          <h4>Offer</h4>
          <a href=""><h4 class="h42"><a href="multiple.html">About</a></h4>
        </div>
        <div class="card" id="first5">
          <p id="text2">Skiing</p>
          <h3>Amirsoy</h3>
          <h4>Offer</h4>
          <a href=""><h4 class="h42"><a href="multiple.html">About</a></h4>
        </div>
      </div>
      <h2 id="cart">Simple <span>Tours</span></h2>
      <div class="row carder" id="row2">
        <div class="card" id="first6">
          <p id="text2">Dinner</p>
          <h3>Mirzo Ulugbek</h3>
          <h4>Offer</h4>
          <a href=""><h4 class="h42" idx="0"><a>About</a></h4>
        </div>
        <div class="card" id="first7">
          <p id="text2">Museum</p>
          <h3>Square</h3>
          <h4>Offer</h4>
          <a href=""><h4 class="h42" idx="1"><a>About</a></h4>
        </div>
        <div class="card" id="first8">
          <p id="text2">Dance</p>
          <h3>Nazarbek</h3>
          <h4>Offer</h4>
          <a href=""><h4 class="h42" idx="2"><a>About</a></h4>
        </div>
        <div class="card" id="first9">
          <p id="text2">Fun</p>
          <h3>Gafur Gulom</h3>
          <h4>Offer</h4>
          <a href=""><h4 class="h42" idx="3"><a>About</a></h4>
        </div>
        <div class="card" id="first10">
          <p id="text2">Gaming</p>
          <h3>Bektemir</h3>
          <h4>Offer</h4>
          <a href=""><h4 class="h42" idx="4"><a>About</a></h4>
        </div>
        <div class="context" id="context">
          <p><h4>Gold at Yunusabad</h4></p>
          <p>
            This tour pack is incredible and very exciting for your emotions
            because of enjoyness
          </p>
          <p><b id="bold">This Tour includes</b></p>
          <p>○ Hotel → Samarkand Gate</p>
          <p>○ Smarkand Gate → Hasti Imam</p>
          <p>○ Hasti Imam → Tashkent TeleTower</p>
          <p>○ TashkentTeleTower → Hotel</p>
          <button>Check Price</button>
        </div>
        <div class="context" id="context">
          <p><h4>Gold at Yunusabad</h4></p>
          <p>
            This tour pack is incredible and very exciting for your emotions
            because of enjoyness
          </p>
          <p><b id="bold">This Tour includes</b></p>
          <p>○ Hotel → Samarkand Gate</p>
          <p>○ Smarkand Gate → Hasti Imam</p>
          <p>○ Hasti Imam → Tashkent TeleTower</p>
          <p>○ TashkentTeleTower → Hotel</p>
          <button>Check Price</button>
        </div>
        <div class="context" id="context">
          <p><h4>Gold at Yunusabad</h4></p>
          <p>
            This tour pack is incredible and very exciting for your emotions
            because of enjoyness
          </p>
          <p><b id="bold">This Tour includes</b></p>
          <p>○ Hotel → Samarkand Gate</p>
          <p>○ Smarkand Gate → Hasti Imam</p>
          <p>○ Hasti Imam → Tashkent TeleTower</p>
          <p>○ TashkentTeleTower → Hotel</p>
          <button>Check Price</button>
        </div>
        <div class="context" id="context">
          <p><h4>Gold at Yunusabad</h4></p>
          <p>
            This tour pack is incredible and very exciting for your emotions
            because of enjoyness
          </p>
          <p><b id="bold">This Tour includes</b></p>
          <p>○ Hotel → Samarkand Gate</p>
          <p>○ Smarkand Gate → Hasti Imam</p>
          <p>○ Hasti Imam → Tashkent TeleTower</p>
          <p>○ TashkentTeleTower → Hotel</p>
          <button>Check Price</button>
        </div>
        <div class="context" id="context">
          <p><h4>Gold at Yunusabad</h4></p>
          <p>
            This tour pack is incredible and very exciting for your emotions
            because of enjoyness
          </p>
          <p><b id="bold">This Tour includes</b></p>
          <p>○ Hotel → Samarkand Gate</p>
          <p>○ Smarkand Gate → Hasti Imam</p>
          <p>○ Hasti Imam → Tashkent TeleTower</p>
          <p>○ TashkentTeleTower → Hotel</p>
          <button>Check Price</button>
        </div>
        <i class="fa-solid fa-circle-chevron-left" id="backward"></i>
      </div>
      <hr />
      <h2 id="cart"><span>Stay in</span> Uzbekistan<span>, Stay</span> Safe</h2>
      <div class="row" id="hotel">
        <div class="card hotel" id="first11">
          <p id="text2">4.7 <i class="fa-solid fa-star"></i></p>
          <h3>Hyatt Regency Tashkent</h3>
        </div>
        <div class="card hotel" id="first12">
          <p id="text2">4.3 <i class="fa-solid fa-star"></i></p>
          <h3>Courtyard by Marriot Tashkent</h3>
        </div>
        <div class="card hotel" id="first13">
          <p id="text2">4.5 <i class="fa-solid fa-star"></i></p>
          <h3>Hillton Tashkent City</h3>
        </div>
        <div class="card hotel" id="first14">
          <p id="text2">4.7 <i class="fa-solid fa-star"></i></p>
          <h3>Ichan Qala Hotel</h3>
        </div>
        <div class="card hotel" id="first15">
          <p id="text2">4.5 <i class="fa-solid fa-star"></i></p>
          <h3>International Hotel Tashkent</h3>
        </div>
      </div>
      <h2 id="cart"><span>Also Stay in</span>Touch</h2>
      <div class="rowman" id="top">
        <a href="#"><i class="fa-brands fa-instagram"></i></a>
        <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
        <a href="#"><i class="fa-brands fa-twitter"></i></a>
        <a href="#"><i class="fa-brands fa-youtube"></i></a>
      </div>
      <div class="rowman">
        <p>Copyright ©️ 2022 VisitUzbekistan. All Rights Reserved TGA</p>
      </div>
      <div class="rowman">
        <p><a href="#" id="cook">Privacy Policy</a></p>
        <p>|</p>
        <p><a href="#" id="cook">Cookie Policy</a></p>
      </div>
    </div>
    <!-- Modal -->
    <div class="modal" id="myModal">
      <!-- Modal Content -->
      <div class="modal-content">
        <span class="close"><i class="fa-solid fa-xmark"></i></span>
        <h2>Hytatt Regency Tashkent</h2>
        <p>Luxury Tashkent Hotel</p>
        <p id="starman">
          4.7 <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i
          ><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i
          ><i class="fa-regular fa-star"></i>
        </p>
        <div class="row">
          <div class="images">
            <img src="./hyatt.jpeg" alt="" />
            <img src="./hyatt2.jpg" alt="" />
            <img src="./hyatt3.webp" alt="" />
            <img src="./hyatt4.jpg" alt="" />
          </div>
          <div class="about">
            <b>About</b>
            <p>
              Near a park in a leafy area, this upscale hotel is a 9-minute walk
              from a metro station, and a 15-minute walk from the State Museum
              of History of Uzbekistan.
            </p>
            <b>Address & contact information</b>
            <p>
              <i class="fa-solid fa-location-dot"></i>  1 A Navoi Avenue,
              Tashkent 100017
            </p>
            <p><i class="fa-solid fa-phone"></i>  8 71 207 12 34</p>
            <button><a href="#"> Book Hotel</a></button>
          </div>
        </div>
      </div>
    </div>
    <div class="modal" id="myModal">
      <!-- Modal Content -->
      <div class="modal-content">
        <span class="close"><i class="fa-solid fa-xmark"></i></span>
        <h2>Hytatt Regency Tashkent</h2>
        <p>Luxury Tashkent Hotel</p>
        <p id="starman">
          4.7 <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i
          ><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i
          ><i class="fa-regular fa-star"></i>
        </p>
        <div class="row">
          <div class="images">
            <img src="./hyatt.jpeg" alt="" />
            <img src="./hyatt2.jpg" alt="" />
            <img src="./hyatt3.webp" alt="" />
            <img src="./hyatt4.jpg" alt="" />
          </div>
          <div class="about">
            <b>About</b>
            <p>
              Near a park in a leafy area, this upscale hotel is a 9-minute walk
              from a metro station, and a 15-minute walk from the State Museum
              of History of Uzbekistan.
            </p>
            <b>Address & contact information</b>
            <p>
              <i class="fa-solid fa-location-dot"></i>  1 A Navoi Avenue,
              Tashkent 100017
            </p>
            <p><i class="fa-solid fa-phone"></i>  8 71 207 12 34</p>
            <button><a href="#"> Book Hotel</a></button>
          </div>
        </div>
      </div>
    </div>
    <div class="modal" id="myModal">
      <!-- Modal Content -->
      <div class="modal-content">
        <span class="close"><i class="fa-solid fa-xmark"></i></span>
        <h2>Hytatt Regency Tashkent</h2>
        <p>Luxury Tashkent Hotel</p>
        <p id="starman">
          4.7 <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i
          ><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i
          ><i class="fa-regular fa-star"></i>
        </p>
        <div class="row">
          <div class="images">
            <img src="./hyatt.jpeg" alt="" />
            <img src="./hyatt2.jpg" alt="" />
            <img src="./hyatt3.webp" alt="" />
            <img src="./hyatt4.jpg" alt="" />
          </div>
          <div class="about">
            <b>About</b>
            <p>
              Near a park in a leafy area, this upscale hotel is a 9-minute walk
              from a metro station, and a 15-minute walk from the State Museum
              of History of Uzbekistan.
            </p>
            <b>Address & contact information</b>
            <p>
              <i class="fa-solid fa-location-dot"></i>  1 A Navoi Avenue,
              Tashkent 100017
            </p>
            <p><i class="fa-solid fa-phone"></i>  8 71 207 12 34</p>
            <button><a href="#"> Book Hotel</a></button>
          </div>
        </div>
      </div>
    </div>
    <div class="modal" id="myModal">
      <!-- Modal Content -->
      <div class="modal-content">
        <span class="close"><i class="fa-solid fa-xmark"></i></span>
        <h2>Hytatt Regency Tashkent</h2>
        <p>Luxury Tashkent Hotel</p>
        <p id="starman">
          4.7 <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i
          ><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i
          ><i class="fa-regular fa-star"></i>
        </p>
        <div class="row">
          <div class="images">
            <img src="./hyatt.jpeg" alt="" />
            <img src="./hyatt2.jpg" alt="" />
            <img src="./hyatt3.webp" alt="" />
            <img src="./hyatt4.jpg" alt="" />
          </div>
          <div class="about">
            <b>About</b>
            <p>
              Near a park in a leafy area, this upscale hotel is a 9-minute walk
              from a metro station, and a 15-minute walk from the State Museum
              of History of Uzbekistan.
            </p>
            <b>Address & contact information</b>
            <p>
              <i class="fa-solid fa-location-dot"></i>  1 A Navoi Avenue,
              Tashkent 100017
            </p>
            <p><i class="fa-solid fa-phone"></i>  8 71 207 12 34</p>
            <button><a href="#"> Book Hotel</a></button>
          </div>
        </div>
      </div>
    </div>
    <div class="modal" id="myModal">
      <!-- Modal Content -->
      <div class="modal-content">
        <span class="close"><i class="fa-solid fa-xmark"></i></span>
        <h2>Hytatt Regency Tashkent</h2>
        <p>Luxury Tashkent Hotel</p>
        <p id="starman">
          4.7 <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i
          ><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i
          ><i class="fa-regular fa-star"></i>
        </p>
        <div class="row">
          <div class="images">
            <img src="./hyatt.jpeg" alt="" />
            <img src="./hyatt2.jpg" alt="" />
            <img src="./hyatt3.webp" alt="" />
            <img src="./hyatt4.jpg" alt="" />
          </div>
          <div class="about">
            <b>About</b>
            <p>
              Near a park in a leafy area, this upscale hotel is a 9-minute walk
              from a metro station, and a 15-minute walk from the State Museum
              of History of Uzbekistan.
            </p>
            <b>Address & contact information</b>
            <p>
              <i class="fa-solid fa-location-dot"></i>  1 A Navoi Avenue,
              Tashkent 100017
            </p>
            <p><i class="fa-solid fa-phone"></i>  8 71 207 12 34</p>
            <button><a href="#"> Book Hotel</a></button>
          </div>
        </div>
      </div>
    </div> hotel
  </body>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <script src="./js/modal.js"></script>
  <script src="./js/tours.js"></script>
  <script>
    AOS.init();
  </script>
</html>
