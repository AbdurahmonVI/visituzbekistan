-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Мар 13 2022 г., 10:42
-- Версия сервера: 10.4.21-MariaDB
-- Версия PHP: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `visituzbekistan`
--

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

CREATE TABLE `articles` (
  `ID` int(11) NOT NULL,
  `main_image` varchar(200) NOT NULL,
  `Header` varchar(200) NOT NULL,
  `Pre_header` varchar(200) NOT NULL,
  `main_text` text NOT NULL,
  `bottom_header` varchar(200) NOT NULL,
  `images` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `articles`
--

INSERT INTO `articles` (`ID`, `main_image`, `Header`, `Pre_header`, `main_text`, `bottom_header`, `images`) VALUES
(1, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `cars`
--

CREATE TABLE `cars` (
  `ID` int(11) NOT NULL,
  `model` varchar(50) NOT NULL,
  `description` varchar(400) NOT NULL,
  `number` int(4) NOT NULL,
  `public` tinyint(1) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `cars`
--

INSERT INTO `cars` (`ID`, `model`, `description`, `number`, `public`, `price`) VALUES
(1, 'Malibu', 'Elegant black, Red lights, GM disks, Number: 000GMD', 6, 0, 300);

-- --------------------------------------------------------

--
-- Структура таблицы `car_deilivers`
--

CREATE TABLE `car_deilivers` (
  `ID` int(11) NOT NULL,
  `location_start` varchar(300) NOT NULL,
  `location_mid` varchar(300) NOT NULL,
  `location_finish` varchar(300) NOT NULL,
  `taking_date` datetime NOT NULL,
  `car_id` int(4) NOT NULL,
  `take_guide` tinyint(1) NOT NULL,
  `rgtour_uniq_id` varchar(100) NOT NULL,
  `tour_id` int(5) NOT NULL,
  `take_money` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `car_deilivers`
--

INSERT INTO `car_deilivers` (`ID`, `location_start`, `location_mid`, `location_finish`, `taking_date`, `car_id`, `take_guide`, `rgtour_uniq_id`, `tour_id`, `take_money`) VALUES
(6, 'Hilton Tashkent', 'Shopping Chorsu', 'Hilton Tashkent', '2022-03-16 14:26:00', 1, 1, '622d8e850c0e5', 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `cities`
--

CREATE TABLE `cities` (
  `ID` int(11) NOT NULL,
  `city` varchar(200) NOT NULL,
  `info_pages` text NOT NULL,
  `instas` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `cities`
--

INSERT INTO `cities` (`ID`, `city`, `info_pages`, `instas`) VALUES
(1, 'Tashkent', 'a:8:{i:0;a:2:{i:0;s:3:\"see\";i:1;s:244:\"Every light in this city means a different story. Imagine yourself witnessing each of them in the heart of two continents. This city will look into your soul directly and make your experiences timeless.\";}i:1;a:3:{i:0;s:5:\"taste\";i:1;s:215:\"Tashkent is waiting for you with its unique tastes from bitter to sweet, sour to salty. Aside from its enchanting historical beauty, Tashkent is the right address even just to try new flavours!\";i:2;s:14:\"taste_tashkent\";}i:2;a:2:{i:0;s:5:\"smell\";i:1;s:297:\"The past, the present and the future full of surprises give this city its fragrance. You will find your childhood in a flower, the excitement of the future in a delicious meal, and the beauty of today in the unique scent of the forest, sea and streets in Tashkent.\";}i:3;a:2:{i:0;s:5:\"touch\";i:1;s:279:\"Feel the texture of Tashkent in the details of an antique building, in the soft fur of a stray cat, in a tulip that fascinates with its color, or in an authentic silk fabric. Tashkent will touch you as you stroll through the streets of this city.\";}i:4;a:2:{i:0;s:6:\"listen\";i:1;s:107:\"Listen to the heartbeats of two continents! If Tashkent was a playlist it would play in shuffle.\";}i:5;a:2:{i:0;s:6:\"routes\";i:1;s:224:\"Every light in this city means a different story. Imagine yourself witnessing each of them in the heart of two continents. This city will look into your soul directly and make your experiences timeless.\";}i:6;a:2:{i:0;s:22:\"10 vibes from Tashkent\";i:1;s:377:\"With its reservoirs that supplied İstanbul with water for many centuries after its foundation, its fountains, and rich fauna, today, Belgrad Forest serves as the city’s lungs. Roughly half an hour’s drive from the city center, Belgrad Forest’s running and cycling tracks make it a matchless destination for sports enthusiasts.\";}i:7;a:2:{i:0;s:8:\"48 hours\";i:1;s:284:\"Straddling the Bosphorus Strait Asia, Tashkent is etched with thousands of years of history, bearing the marks of the Ancient Greeks, the Persians, the Romans, the Byzantines, the Uzbeks, and the Silk Road traders who`ve lived here over the centuries.\";}}', 'gfjdskflgdgjdjlgsdjgjldsfjgsdgksjdlgksdjgsdjg');

-- --------------------------------------------------------

--
-- Структура таблицы `events`
--

CREATE TABLE `events` (
  `ID` int(11) NOT NULL,
  `datte` datetime NOT NULL,
  `tour_id` int(5) NOT NULL,
  `passengers` text NOT NULL,
  `seats_left` int(4) NOT NULL,
  `car_type_id` int(2) NOT NULL,
  `Location_center` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `events`
--

INSERT INTO `events` (`ID`, `datte`, `tour_id`, `passengers`, `seats_left`, `car_type_id`, `Location_center`) VALUES
(1, '2022-03-17 10:40:00', 1, 'a:0:{}', 40, 3, 'Tashkent, Amir Temur'),
(2, '2022-03-31 17:00:00', 1, 'a:0:{}', 40, 3, 'Tashkent, Amir Temur');

-- --------------------------------------------------------

--
-- Структура таблицы `fpswrd`
--

CREATE TABLE `fpswrd` (
  `ID` int(11) NOT NULL,
  `code` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `checked` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `individual_tours`
--

CREATE TABLE `individual_tours` (
  `ID` int(11) NOT NULL,
  `tour_name` varchar(200) NOT NULL,
  `location` varchar(800) NOT NULL,
  `location_text` varchar(200) NOT NULL,
  `price` varchar(800) NOT NULL,
  `descc` text NOT NULL,
  `species` varchar(400) NOT NULL,
  `strict_timing` varchar(300) NOT NULL,
  `approx_duration` int(6) NOT NULL,
  `cangroup` tinyint(1) NOT NULL,
  `city` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `individual_tours`
--

INSERT INTO `individual_tours` (`ID`, `tour_name`, `location`, `location_text`, `price`, `descc`, `species`, `strict_timing`, `approx_duration`, `cangroup`, `city`) VALUES
(1, 'Chorsu Tour Tashkent', 'a:2:{i:0;d:41.317384;i:1;d:69.226248;}', 'Shopping Chorsu', 'a:2:{i:0;i:200;i:1;i:70;}', 'fsdjflksdflksdfjsakfsafdsdvnkskdvnjnjnvkjndjfnvjkdnkvjdnkvndk', 'Zor de dede', 'f', 30, 1, 'Tashkent');

-- --------------------------------------------------------

--
-- Структура таблицы `mail`
--

CREATE TABLE `mail` (
  `ID` int(40) NOT NULL,
  `email` varchar(500) NOT NULL,
  `code` varchar(200) NOT NULL,
  `checked` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `multiple_tours`
--

CREATE TABLE `multiple_tours` (
  `ID` int(11) NOT NULL,
  `tour_name` varchar(200) NOT NULL,
  `price` int(8) NOT NULL,
  `descc` text NOT NULL,
  `species` text NOT NULL,
  `days` int(2) NOT NULL,
  `rating` int(1) NOT NULL,
  `header` varchar(400) NOT NULL,
  `description` text NOT NULL,
  `more_text` text NOT NULL,
  `more_species` text NOT NULL,
  `images` text NOT NULL,
  `consist_of` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `offers`
--

CREATE TABLE `offers` (
  `ID` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `location` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `registred_tours`
--

CREATE TABLE `registred_tours` (
  `ID` int(11) NOT NULL,
  `uniq_id` varchar(50) NOT NULL,
  `tour_id` int(5) NOT NULL,
  `type` varchar(30) NOT NULL,
  `date` datetime NOT NULL,
  `number_people` varchar(200) NOT NULL,
  `price` int(11) NOT NULL,
  `car_type_id` int(3) NOT NULL,
  `Location_from` varchar(800) NOT NULL,
  `user_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `registred_tours`
--

INSERT INTO `registred_tours` (`ID`, `uniq_id`, `tour_id`, `type`, `date`, `number_people`, `price`, `car_type_id`, `Location_from`, `user_id`) VALUES
(23, '622d8e850c0e5', 1, 'Individual', '2022-03-16 14:26:00', 'a:2:{i:0;s:1:\"2\";i:1;s:1:\"4\";}', 1280, 1, 'Hilton Tashkent', '6157ff493cd8d');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `ID` int(20) NOT NULL,
  `uniq_id` varchar(200) NOT NULL,
  `nickname` varchar(500) NOT NULL,
  `firstname` varchar(400) NOT NULL,
  `lastname` varchar(400) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(600) NOT NULL,
  `mobile_number` varchar(200) NOT NULL,
  `img` varchar(600) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`ID`, `uniq_id`, `nickname`, `firstname`, `lastname`, `email`, `password`, `mobile_number`, `img`) VALUES
(5, '6157ff493cd8d', '@aisolar', 'Muhammadiyor', 'Shakirov', 'shakirov.muhammadiyor6@gmail.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'Muhammad Al-Xorazmiy', 'user.jpg'),
(10, '6228ce559f3ea', '@qochqor', 'Muhammadiyor', 'Shakirov', 'playstation4assassinscreed@gmail.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', '998971554246', '1646841500Al-Xorazmiy (5).png');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `car_deilivers`
--
ALTER TABLE `car_deilivers`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `fpswrd`
--
ALTER TABLE `fpswrd`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `individual_tours`
--
ALTER TABLE `individual_tours`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `mail`
--
ALTER TABLE `mail`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `multiple_tours`
--
ALTER TABLE `multiple_tours`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `registred_tours`
--
ALTER TABLE `registred_tours`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `articles`
--
ALTER TABLE `articles`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `cars`
--
ALTER TABLE `cars`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `car_deilivers`
--
ALTER TABLE `car_deilivers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `cities`
--
ALTER TABLE `cities`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `events`
--
ALTER TABLE `events`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `fpswrd`
--
ALTER TABLE `fpswrd`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT для таблицы `individual_tours`
--
ALTER TABLE `individual_tours`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `mail`
--
ALTER TABLE `mail`
  MODIFY `ID` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `multiple_tours`
--
ALTER TABLE `multiple_tours`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `offers`
--
ALTER TABLE `offers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `registred_tours`
--
ALTER TABLE `registred_tours`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
