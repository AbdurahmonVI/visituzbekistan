window.onload = () => {
		let radios = document.querySelectorAll("div.radio");
		let last = radios[0];

		radios.forEach(function(element) {
			element.onclick = () => {
				clear(last);
				element.style.color = "#006eb6";
				element.style.border = "2px solid #006eb6";
				element.querySelector("input").click();
				last = element;
			}
		});

		function clear (x) {
			x.style.color = "black";
			x.style.border = "2px solid black";
		}
	}