var modal = document.querySelectorAll("div.modal");
var hotel = document.querySelectorAll("div.hotel");
var span = document.querySelectorAll(".close");

hotel.forEach(function(element, index) {
    element.onclick = () => {
        modal[index].style.display = "block";
    }
});

span.forEach(function(element, index) {
    element.onclick = () => {
        modal[index].style.display = "none";
    }
});

span.onclick = function () {
  modal.style.display = "none";
};
