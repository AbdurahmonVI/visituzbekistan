const form = document.querySelector("form#form"),
	  btn = form.querySelector("button"),
	  errorField = form.querySelector("div.error"),
	  loading = form.querySelector("h1>i");

form.onsubmit = (e) => {
	e.preventDefault();
}
 
btn.onclick = () => {
	errorField.style.display = "none";
	loading.classList.add("active");
	let xhr = new XMLHttpRequest();
	xhr.open("POST", "php/signup-complete.php", true);
	xhr.onload = () => {
		if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
			loading.classList.remove("active");
			let data = xhr.response;
			errorField.style.display = "flex";
			if (data.length != 13) {
				errorField.textContent = data;
			} else {
				errorField.style.backgroundColor = 'grey';
				errorField.textContent = "We are send the verification code to your email address";
				setInterval(function () {
					let xhl = new XMLHttpRequest();
					xhl.open("POST", "php/signup-complete2.php", true);
					xhl.onload = () => {
						if (xhl.readyState === XMLHttpRequest.DONE && xhl.status === 200) {
							let data2 = xhl.response;
							if (data2 == "success") {
								location.href = "php/obrabotka.php";
							}
						}
					}
					let fD = new FormData (form);
					fD.append('uniq_id', data);
					xhl.send(fD);
				}, 1000);
			}
		}
	}
	xhr.send(new FormData(form));
}