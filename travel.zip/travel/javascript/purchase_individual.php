<script type="text/javascript">
	let item;
	let formm = document.querySelector("#form");

	function kere () {
		item = document.querySelectorAll("#next")
		item = item[item.length - 1];
		item.addEventListener('click', function () {
			formm.innerHTML	+= vapshe(item.getAttribute("value"));
			kere();
		});
	}

	kere();

	function vapshe (num) {
		
	}
</script>