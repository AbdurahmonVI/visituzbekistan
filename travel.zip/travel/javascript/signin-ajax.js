const form = document.querySelector("form#form"),
	  btn = form.querySelector("button"),
	  errorField = form.querySelector("div.error"),
	  loading = form.querySelector("h1>i");

form.onsubmit = (e) => {
	e.preventDefault();
}

btn.onclick = () => {
	errorField.style.display = "none";
	loading.classList.add("active");
	let xhr = new XMLHttpRequest();
	xhr.open("POST", "php/signin-complete.php", true);
	xhr.onload = () => {
		if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
			loading.classList.remove("active");
			let data = xhr.response;
			if (data == "success")
				// location.href = "homepage.php";
				location.href = "php/obrabotka.php";
			else {
				errorField.style.display = 'flex';
				errorField.textContent = data;
			}
		}
	}
	xhr.send(new FormData(form));
}