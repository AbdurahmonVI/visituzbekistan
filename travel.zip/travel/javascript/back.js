let back = document.querySelector("div.back");
	back.addEventListener('click', function () {
		window.history.back();
	});
