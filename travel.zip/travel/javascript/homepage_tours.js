let qolip = document.getElementById("row1");
let qolip2 = document.getElementById("backward");
let aman = document.querySelectorAll("div#row2 h4.h42");
let cont = document.querySelectorAll("div#row2 div.context");
aman.forEach((element) => {
  element.addEventListener("click", function () {
    element.parentElement.style = "width: 20%";
    for (let i = 0; i < aman.length; i++) {
      let item = aman[i];
      if (item != element) {
        item.parentElement.style.transform = `translateX(-${i * 80}px)`;
        item.parentElement.style.opacity = "0";
        item.parentElement.style.display = "none";
        qolip2.style = "display: block";
        qolip.style = "justify-content: flex start";
      }
    }
    cont[Number(element.getAttribute("idx"))].style = "opacity: 1";
  });
});
qolip2.addEventListener("click", function () {
  aman.forEach((element) => {
    cont.style.transitionDelay = 0;
    cont.style.transition = 0;
    element.parentElement.style.transform = "translateX(0px)";
    element.parentElement.style.opacity = "1";
    qolip.style = "justify-content: space-between";
    qolip2.style = "display:none";
    element.parentElement.style.display = "flex";
    element.parentElement.style = "width: 100%";
    cont.style.opacity = 0;
  });
});
