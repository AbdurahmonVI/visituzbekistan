const eye = document.querySelector("i.fa-eye"),
	  input = document.querySelector("input#password");

eye.onclick = () => {
	if (input.type == "password") input.type = "text"
	else input.type = "password"
}