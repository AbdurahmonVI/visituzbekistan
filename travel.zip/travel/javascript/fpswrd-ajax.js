const form = document.querySelector("form#form"),
	  btn = form.querySelector("button"),
	  errorField = form.querySelector("div.error"),
	  loading = form.querySelector("h1>i"),
	  type = form.querySelector("input#get").value;

form.onsubmit = (e) => {
	e.preventDefault();
}


if (type == 1) {
	btn.onclick = () => {
		let login = form.querySelector("input#login").value;
		errorField.style.display = "none";
		loading.classList.add("active");
		let xhr = new XMLHttpRequest();
		xhr.open("POST", "php/fpswrd-complete.php", true);
		xhr.onload = () => {
			if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
				loading.classList.remove("active");
				let data = xhr.response;
				if (data == "success")
					location.href = "password.php?type=code&email=" + login;
				else {
					errorField.style.display = 'flex';
					errorField.textContent = data;
				}
			}
		}
		xhr.send(new FormData(form));
	}
} else if (type == 2) {
	let login = new URLSearchParams(window.location.search).get('email');
	if (login == null) {
		location.href = "signup.php";
	}
	btn.onclick = () => {
		errorField.style.display = "none";
		loading.classList.add("active");
		let xhr = new XMLHttpRequest();
		xhr.open("POST", "php/fpswrd-check_sent.php", true);
		xhr.onload = () => {
			if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
				loading.classList.remove("active");
				let data = xhr.response;
				if (data == "success") {
					location.href = "password.php?type=chpswrd&email=" + login;
				} else {
					errorField.style.display = 'flex';
					errorField.textContent = data;
				}
			}
		}
		
		let fd = new FormData (form);
		fd.append("login", login);
		xhr.send(fd);
	}
} else if (type == 3) {
	let login = new URLSearchParams(window.location.search).get('email');
	if (login == null) {
		location.href = "signup.php";
	}
	btn.onclick = () => {
		errorField.style.display = "none";
		loading.classList.add("active");
		let xhr = new XMLHttpRequest();
		xhr.open("POST", "php/fpswrd-change.php", true);
		xhr.onload = () => {
			if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
				loading.classList.remove("active");
				let data = xhr.response;
				if (data == "success") {
					location.href = "signin.php";
				} else {
					errorField.style.display = 'flex';
					errorField.textContent = data;
				}
			}
		}
		
		let fd = new FormData (form);
		fd.append("login", login);
		xhr.send(fd);
	}
}