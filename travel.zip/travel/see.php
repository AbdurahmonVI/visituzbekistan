<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" href="./favicon.ico" type="image/x-icon" />
    <title>𝐕𝐢𝐬𝐢𝐭𝐔𝐳𝐛𝐞𝐤𝐢𝐬𝐭𝐚𝐧.𝐮𝐳</title>
    <link rel="stylesheet" type="text/css" href="./css/article.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
      integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
  </head>
  <body>
    <!-- <a href=""
      ><div class="back"><i class="fa-solid fa-house"></i></div
    ></a> -->
    <a href="index.html#first"
      ><i class="fa-solid fa-ellipsis" id="stick"></i
    ></a>
    <div class="hero" style="background-image: url(img/tashkent2.jpg);">
      <div class="content">
        <h2 id="big" data-aos="fade-down">see</h2>
        <h2 data-aos="fade-down" data-aos-delay="100">Tashkent</h2>
        <p id="text" data-aos="fade-down" data-aos-delay="200">
          Every light in this city means a different story. Imagine yourself
          witnessing each of them in the heart of two continents. This city will
          look into your soul directly and make your experiences timeless.
        </p>
        <a href="#article1"
          ><button data-aos="zoom-in-down" data-aos-delay="300">
            See More
          </button></a
        >
      </div>
    </div>
    <div class="article" id="article1">
      <h1 class="title">Pulvinar mattis nunc sed blandit.</h1>
      <h5 class="sub-title">
        Arcu ac tortor dignissim convallis aenean et tortor at risus viverra
        adipiscing.
      </h5>
      <hr class="line" />
      <div class="text">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
        velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
        occaecat cupidatat non proident, sunt in culpa qui officia deserunt
        mollit anim id est laborum. <br />
        <br />
        <span class="img-title"> Lorem. </span>
        <br /><br />
        <div class="img" style="background-image: url(img/tashkent1.jpg);"></div>
        <br /><br />
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
        velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
        occaecat cupidatat non proident, sunt in culpa qui officia deserunt
        mollit anim id est laborum.
        <div class="card">
          <div class="img-card" style="background-image: url(img/tashkent2.jpg);"></div>
          <span class="card-title">
            Lorem.
            <h5 style="color: #eee; font-weight: 500">
              Lorem ipsum dolor sit amet.
            </h5>
          </span>
          <a href="" class="more">Learn more.</a>
        </div>
        <hr class="line" />
      </div>
      <div class="text">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
        velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
        occaecat cupidatat non proident, sunt in culpa qui officia deserunt
        mollit anim id est laborum. <br />
        <br />
        <span class="img-title"> Lorem. </span>
        <br /><br />
        <div
          class="img"
          style="background-image: url('./img/Tashkent2.jpg')"
        ></div>
        <br /><br />
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
        velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
        occaecat cupidatat non proident, sunt in culpa qui officia deserunt
        mollit anim id est laborum.
        <div class="card">
          <div
            class="img-card"
            style="background-image: url('./img/Tashkent2.jpg')"
          ></div>
          <span class="card-title">
            Lorem.
            <h5 style="color: #eee; font-weight: 500">
              Lorem ipsum dolor sit amet.
            </h5>
          </span>
          <a href="" class="more">Learn more</a>
        </div>
        <hr class="line" />
      </div>
      <div class="gallery">
        <img src="./img/osh.jpg" class="gallery-item osh" />
        <img src="./img/manti.jpg" class="gallery-item" />
        <img src="./img/somsa.jpg" class="gallery-item" />
        <img src="./img/kartoshka.jpg" class="gallery-item" />
        <img src="./img/lagman.jpg" class="gallery-item" />
      </div>
    </div>
    <div class="end">
      <div class="rowman" id="top">
        <a href="#"><i class="fa-brands fa-instagram"></i></a>
        <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
        <a href="#"><i class="fa-brands fa-twitter"></i></a>
        <a href="#"><i class="fa-brands fa-youtube"></i></a>
      </div>
      <div class="rowman">
        <p>Copyright ©️ 2022 VisitUzbekistan. All Rights Reserved TGA</p>
      </div>
      <div class="rowman">
        <p><a href="#" id="cook">Privacy Policy</a></p>
        <p>|</p>
        <p><a href="#" id="cook">Cookie Policy</a></p>
      </div>
    </div>
  </body>
</html>
