<?php 
	session_start();
	include '../php/config.php';

	if (isset($_SESSION['checked_options']['type'])) {
		if ($_SESSION['checked_options']['type'] == "Group") {
			$a = "existed_dates";
		} else {
			$a = "comments";
		}
	} else {
		if (isset($_SESSION['tour_species'])) {
			header("Location: type.php?tour_id=".$_SESSION['tour_species']['ID']);
		} else {
			header("Location: type.php");
		}
	}

	function ctodate ($str) {
		$monthes = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

		return $str[8].$str[9]." ".$monthes[intval(($str[5] != "0" ? $str[5] : "").$str[6]) - 1]." ".$str[10].$str[11].$str[12].$str[13].$str[14].$str[15];
	}

	function back ($a, $b) {
		$_SESSION['error'] = [$a, $b];
		header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
	}

	if (isset($_POST[$a])) {
		if ($a == "comments") {
			$_SESSION['checked_options']['comments'] = htmlspecialchars(trim($_POST['comments']));
		} else {
			$kere = $_POST['existed_dates'];
			$even = mysqli_query($connection, "SELECT * FROM events WHERE ID = '$kere' LIMIT 1");
			$event = mysqli_fetch_assoc($even);
			if (!is_numeric($_POST['existed_dates'])) {
				back($a, "Hacker");
			} elseif (mysqli_num_rows($even) == 0) {
				back($a, "Selected tour is not exist");
			} elseif ($_SESSION['checked_options']['people'] > $event['seats_left']) {
				back($a, "Available seats number is not enough");
			} elseif (mysqli_num_rows(mysqli_query($connection, "SELECT ID FROM registred_tours WHERE type = 'Group' AND date = '".$event['datte']."' AND user_id = '".$_SESSION['uniq_id']."' AND Location_from = '".$event['Location_center']."' LIMIT 1")) == 1) {
				back($a, "You have already registered for this tour");
			} else {
				$_SESSION['checked_options']['existed_dates'] = $_POST['existed_dates'];
				$_SESSION['tour_species']['event'] = [$event['datte'], $event['car_type_id'], $event['Location_center']];
			}
		}
	} else {
		header("Location: type.php?tour_id=".$_SESSION['tour_species']['ID']);
	}
 ?>

 <?php include 'head_layout.php'; ?>
 <p class="thanks">Thanks for booking<br>We'll send details to your email day before</p>
 <div class="section2">
 	<i class="fa-solid fa-house home"></i>
 	<form action="#" method="POST">
 		<p class="error"></p>
 		<h1>Overall</h1>
 		 <?php if ($_SESSION['checked_options']['type'] == "Group"): ?>
 		 	<p>Type of tour: <?=$_SESSION['checked_options']['type']?></p>
 		 	<p>Number of adults: <?=$_SESSION['checked_options']['adults']?></p>
 		 	<p>Number of kids: <?=$_SESSION['checked_options']['kids']?></p>
 		 	<p>Date of tour: <?=ctodate(mysqli_fetch_assoc(mysqli_query($connection, "SELECT datte FROM events WHERE ID = {$_SESSION['checked_options']['existed_dates']} LIMIT 1"))['datte'])?></p>
 		 	<p>Total Price: $<?php
 		 		$prices = unserialize($_SESSION['tour_species']['price']);
 		 		$total_price = $_SESSION['checked_options']['adults'] * $prices[0] + $_SESSION['checked_options']['kids'] * $prices[1];
 		 		echo $total_price;
 		 		$_SESSION['tour_species']['event'][3] = $total_price;
 		 ?></p>
 		 	<p>We'll wait you in: <?=$event['Location_center']?></p>
 		 <?php else: ?>
 		 	<?php $car = mysqli_fetch_assoc(mysqli_query($connection, "SELECT model, price FROM cars WHERE ID = ".$_SESSION['checked_options']['car_type']." ")); ?>
 		 	<p>Type of tour: <?=$_SESSION['checked_options']['type']?></p>
 		 	<p>Number of adults: <?=$_SESSION['checked_options']['adults']?></p>
 		 	<p>Number of kids: <?=$_SESSION['checked_options']['kids']?></p>
 		 	<p>Date of tour: <?=ctodate($_SESSION['checked_options']['datetime'])?></p>
 		 	<p>Location: <?=$_SESSION['checked_options']['location']?></p>
 		 	<p>Car type: <?=$car['model']?></p>
 		 	<p>Total Price: $<?php 
 		 		$prices = unserialize($_SESSION['tour_species']['price']);
 		 		$total_price = $_SESSION['checked_options']['adults'] * $prices[0] + $_SESSION['checked_options']['kids'] * $prices[1] + 2 * $car['price'];
 		 		$_SESSION['tour_species']['event'][0] = $total_price;
 		 		echo $total_price;
 		 ?></p>
 		 <?php endif ?>
 		<input type="hidden" value="zza45kaja5672" name="09xbhjut2">
 		<div class="button">
			<button type="submit">Next<i class="fa-solid fa-angles-right"></i></button>
		</div>
 	</form>
 	<div class="back"><i class="fa-solid fa-angles-left"></i> Back</div>
 </div>
</body>
<script type="text/javascript" src="../javascript/back.js"></script>
<script type="text/javascript">
	let form = document.querySelector("form");
	let error = document.querySelector("p.error");
	let s1 = document.querySelector("div.section1");
	let s2 = document.querySelector("div.section2"); 
	form.addEventListener("submit", function (e) {
		e.preventDefault();
		let xhr = new XMLHttpRequest();
		xhr.open("POST", "../php/registred_tour.php", true);
		xhr.onload = () => {
			if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
				if (xhr.response == "success") {
					setTimeout(function () {
						s2.style.opacity = '0';
						s2.style.flex = "0";
						s2.style.width = "0px";
						setTimeout(function () {
							s1.querySelector("div.species").style.opacity = '0';
							s1.style.width = "100%";
							s1.style.flex = "1";
							s1.querySelector("div.species").style = "flex: 0; height:0px;";
							setTimeout(function () {
								s1.querySelector("div.image").style.filter = 'brightness(5%)';
								document.querySelector("p.thanks").style.opacity = '1';
								setTimeout(function () {
									window.location.replace("../user_page.php");
								}, 3000);
							}, 1000);
						}, 1000);
					}, 100);
				} else if (xhr.response[0] == "f") {
					window.location.replace(xhr.response.substring(1));
				} else {
					error.innerHTML = xhr.response;
				}
			}
		}
		xhr.send(new FormData(form));
	});	
</script>
</html>