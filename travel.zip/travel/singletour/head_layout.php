<?php 
	if (!isset($_GET['tour_id']) and !isset($_SESSION['tour_species'])) {
		header("Location: ../homepage.php?city=tashkent");
	}

	if (!isset($_SESSION['uniq_id'])) {
		header("Location: ../homepage.php?city=tashkent");
	}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="../styles/single.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
	<div class="section1">
		<div class="image" style="background-image: url(../images/singletour/<?=str_replace(" ", "_", strtolower($_SESSION['tour_species']['tour_name']))?>.jpg);"></div>
		<div class="species">
			<div class="spec">
				<div class="icon">
					<i class="fa-solid fa-circle-info"></i>
				</div>
				<div class="text">
					<h3>Name of tour</h3>
					<p><?=$_SESSION['tour_species']['tour_name']?></p>
				</div>
			</div>
			<div class="spec">
				<div class="icon">
					<i class="fa-solid fa-location-dot"></i>
				</div>
				<div class="text">
					<h3>Location</h3>
					<p><?=$_SESSION['tour_species']['location_text']?></p>
				</div>
			</div>
			<div class="spec">
				<div class="icon">
					<i class="fa-solid fa-clock"></i>
				</div>
				<div class="text">
					<h3>Approximate Duration</h3>
					<p><?=$_SESSION['tour_species']['approx_duration']?> minutes</p>
				</div>
			</div>
		</div>
	</div>