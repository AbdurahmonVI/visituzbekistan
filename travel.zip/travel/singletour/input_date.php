<?php 
	session_start();
	include '../php/config.php';

	$a = "car_type";

	function back ($a, $b) {
		$_SESSION['error'] = [$a, $b];
		header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
	}

	if (isset($_POST['car_type'])) {
		if (empty($_POST['car_type'])) {
			back($a, "Please fill car_type");
		} else if (mysqli_num_rows(mysqli_query($connection, "SELECT price FROM cars WHERE ID = ".$_POST['car_type']." AND number >= ".$_SESSION['checked_options']['people']." LIMIT 1")) == 0) {
			back($a, "There's no any cars that fit you");
		} else {
			$_SESSION['checked_options']['car_type'] = $_POST['car_type'];
		}
	} else {
		if ($_SESSION['error'][0] == "input_date") {
			$kre = $_SESSION['error'][1];
			unset($_SESSION['error']);
		} else {
			header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
		}
	}
?>
<?php include 'head_layout.php'; ?>
<div class="section2">
	<i class="fa-solid fa-house home"></i>
	<form action="comments.php" method="POST">
		<h1>Select date</h1>
		<?php if (isset($kre)): ?>
			<p class="error"><?=$kre?></p>
		<?php endif ?>
		<div class="inputs_texts">
			<div class="inputt">
				<div class="label">Date:</div>
				<div class="input"><input type="date" name="date" required></div>
			</div>
		<?php
			if ($_SESSION['tour_species']['strict_timing'][0] == "a") {
				echo '</div><div class="radios">';
				$k = unserialize($_SESSION['tour_species']['strict_timing']);
				for ($i=0; $i < count($k); $i++) { 
					echo '<div class="radio">
						<input type="radio" name="time" value="'.$k[$i].'" required>
						<i class="fa-solid fa-clock"></i>
						<p>'.$k[$i].'</p>
					</div>';
				}
				echo '</div>';
			} else {
				echo '<div class="inputt">
							<div class="label">Time:</div>
							<div class="input"><input type="time" name="time" required></div>
						</div>
					</div>';
			}
		?>
		
		<div class="button">
			<button type="submit">Next<i class="fa-solid fa-angles-right"></i></button>
		</div>
	</form>
	<div class="back"><i class="fa-solid fa-angles-left"></i> Back</div>
</div>
</body>
<!-- if stict timing radios.js include -->
<script type="text/javascript" src="../javascript/back.js"></script>
<script type="text/javascript" src="../javascript/radio.js"></script>
</html>