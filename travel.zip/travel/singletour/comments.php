<?php 
	session_start();

	$a = "input_date";

	function back ($a, $b) {
		$_SESSION['error'] = [$a, $b];
		header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
	}

	function validateDate($date, $format = 'd-m-Y'){
	    $d = DateTime::createFromFormat($format, $date);
	    return $d && $d->format($format) === $date;
	}

	function createtimefs ($x, $y) {
		return $x." ".$y.":00";
	}

	if (isset($_POST['date'])) {
		if (validateDate($_POST['date'])) {
			back($a, "Date is not valid");
			// Check is date valid or not;
		} else if (preg_match("/^(?:2[0-3]|[01][0-9]):[0-5][0-9]$/", $_POST['time']) == 0) {
			back($a, "Time is not valid");
		} else if ($_SESSION['tour_species']['strict_timing'][0] == "a") {
			if (!in_array($_POST['time'], unserialize($_SESSION['tour_species']['strict_timing']))) {
				back($a, "There's no time");
			} else {
				$_SESSION['checked_options']['datetime'] = createtimefs($_POST['date'], $_POST['time']);
			}
		} else {
			$_SESSION['checked_options']['datetime'] = createtimefs($_POST['date'], $_POST['time']);	
		}
	} else {
		if ($_SESSION['error'][0] == "comments") {
			$kre = $_SESSION['error'][1];
			unset($_SESSION['error']);
		} else {
			header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
		}
	}
?>
<?php include 'head_layout.php'; ?>
<div class="section2">
	<i class="fa-solid fa-house home"></i>
	<form action="summarize.php" method="POST">
		<h1>Comments\Demands</h1>
		<?php if (isset($kre)): ?>
			<p class="error"><?=$kre?></p>
		<?php endif ?>
		<textarea name="comments" id="" cols="30" rows="10" placeholder="You can write your demand (If you wish)"></textarea>
		<div class="button">
			<button type="submit">Next<i class="fa-solid fa-angles-right"></i></button>
		</div>
	</form>
	<div class="back"><i class="fa-solid fa-angles-left"></i> Back</div>
</div>
</body>
<script type="text/javascript" src="../javascript/back.js"></script>
</html>