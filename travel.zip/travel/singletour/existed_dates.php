<?php 
	session_start();

	$a = "number_of_people";

	function back ($a, $b) {
		$_SESSION['error'] = [$a, $b];
		header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
	}

	function ctodate ($str) {
		$monthes = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

		return $str[8].$str[9]." ".$monthes[intval(($str[5] != "0" ? $str[5] : "").$str[6]) - 1]." ".$str[10].$str[11].$str[12].$str[13].$str[14].$str[15];
	}

	if (isset($_POST['adults'])) {
		if (!is_numeric($_POST['adults'])) {
			back($a, "Adults please fill");
		} elseif (!is_numeric($_POST['kids'])) {
			back($a, "Kids please fill");
		} elseif (intval($_POST['adults']) + intval($_POST['kids']) == 0) {
			back($a, "Number of people cant be 0");
		} else {
			$_SESSION['checked_options']['people'] = intval($_POST['adults']) + intval($_POST['kids']);
			$_SESSION['checked_options']['adults'] = $_POST['adults'];
			$_SESSION['checked_options']['kids'] = $_POST['kids']; 
		}
	} else {
		if ($_SESSION['error'][0] == "existed_dates") {
			$kre = $_SESSION['error'][1];
			unset($_SESSION['error']);
		} else {
			header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
		}
	}
?>
<?php include 'head_layout.php'; ?>
	<div class="section2">
		<i class="fa-solid fa-house home"></i>
		<form action="summarize.php" method="POST">
			<h1>Existed Dates</h1>
			<?php if (isset($kre)): ?>
				<p class="error"><?=$kre?></p>
			<?php endif ?>
			<div class="radios">
				<?php 
					include '../php/config.php';
					$tour_id = $_SESSION['tour_species']['ID'];
					$available_dates = mysqli_query($connection, "SELECT * FROM events WHERE tour_id = $tour_id ORDER BY datte LIMIT 4");
					if (mysqli_num_rows($available_dates) == 0) {
						echo 'No tours availbale';
					} else {
						while ($row = mysqli_fetch_assoc($available_dates)) {
							echo '<div class="radio">
								<input type="radio" name="existed_dates" value="'.$row['ID'].'" required>
								<p>'.ctodate($row['datte']).'</p>
								<p>'.$row['seats_left'].' seats Left</p>
							</div>';
						}
					}
				 ?>
			</div>
			<div class="button">
				<button type="submit">Next<i class="fa-solid fa-angles-right"></i></button>
			</div>
		</form>
		<div class="back"><i class="fa-solid fa-angles-left"></i> Back</div>
	</div>
</body>
<script type="text/javascript" src="../javascript/radio.js"></script>
<script type="text/javascript" src="../javascript/back.js"></script>
</html>