<?php 
	session_start();

	$a = "location";

	function back ($a, $b) {
		$_SESSION['error'] = [$a, $b];
		header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
	}

	if (isset($_POST['location'])) {
		if (empty($_POST['location'])) {
			back($a, "Please fill location");
		} else {
			$_SESSION['checked_options']['location'] = $_POST['location'];
		}
	} else {
		if ($_SESSION['error'][0] == "car_type") {
			$kre = $_SESSION['error'][1];
			unset($_SESSION['error']);
		} else {
			header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
		}
	}
?>
<?php include 'head_layout.php'; ?>
<div class="section2">
	<i class="fa-solid fa-house home"></i>
	<form action="input_date.php" method="POST">
		<h1>Select a car</h1>
		<?php if (isset($kre)): ?>
			<p class="error"><?=$kre?></p>
		<?php endif ?>
		<div class="radios">
			<?php 
				include '../php/config.php';
				$cars = mysqli_query($connection, "SELECT * FROM cars WHERE number >= ".$_SESSION['checked_options']['people']." AND public = false ORDER BY price");
				if (mysqli_num_rows($cars) == 0) {
					echo 'Sorry, but there are not cars that fit your number of people';
				} else {
					while ($row = mysqli_fetch_assoc($cars)) {
						echo '<div class="radio">
							<input type="radio" name="car_type" value="'.$row['ID'].'" required>
							<i class="fa-solid fa-car"></i>
							<p>'.$row['model'].'<br>$'.$row['price'].'</p>
						</div>';
					}
				}
			 ?>
		</div>
		<div class="button">
			<button type="submit">Next<i class="fa-solid fa-angles-right"></i></button>
		</div>
	</form>
	<div class="back"><i class="fa-solid fa-angles-left"></i> Back</div>
</div>
</body>
<script type="text/javascript" src="../javascript/back.js"></script>
<script type="text/javascript" src="../javascript/radio.js"></script>
</html>