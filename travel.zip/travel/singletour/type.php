<?php 
	include '../php/config.php';
	session_start();

	if (!isset($_GET['tour_id'])) {
		echo 'Bad request'; exit;
	} else {
		$k = $_GET['tour_id'];
	}

	$getsql = mysqli_query($connection, "SELECT * FROM individual_tours WHERE ID = '$k' LIMIT 1");

	if (mysqli_num_rows($getsql) == 0) {
		echo 'No such tours founded'; exit;
	} else {
		$_SESSION['tour_species'] = mysqli_fetch_assoc($getsql);
		$_SESSION['checked_options'] = [];
	}
	unset($_SESSION['error']);
?>
<?php include 'head_layout.php'; ?>
	<div class="section2">
		<i class="fa-solid fa-house home"></i>
		<form action="number_of_people.php" method="POST">
			<h1>Type of tour</h1>
			<?php if (isset($kre)): ?>
				<p style="color:red; font-weight: 900;"><?=$k?></p>
			<?php endif ?>
			<div class="radios">
					<?php if ($_SESSION['tour_species']['cangroup']): ?>
						<div class="radio">
						<input type="radio" name="type" value="Group" required>
						<i class="fa-solid fa-user-group"></i>
						<p>Group</p>
						</div> 
					<?php else: ?>
						<div class="radio" style="border:2px solid grey;">
						<input type="radio" name="type" value="Group" disabled>
						<i class="fa-solid fa-user-group" style="color:grey;"></i>
						<p style="color: grey;">Group</p>
						</div>
					<?php endif ?>
				<div class="radio">
					<input type="radio" name="type" value="Individual" required>
					<i class="fa-solid fa-user"></i>
					<p>Individual</p>
				</div>
			</div>
			<div class="button">
				<button type="submit">Next<i class="fa-solid fa-angles-right"></i></button>
			</div>
		</form>
	</div>
</body>
<script type="text/javascript" src="../javascript/radio.js"></script>
</html>