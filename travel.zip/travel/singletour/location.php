<?php 
	session_start();

	$a = "number_of_people";

	function back ($a, $b) {
		$_SESSION['error'] = [$a, $b];
		header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
	}

	if (isset($_POST['adults'])) {
		if (!is_numeric($_POST['adults'])) {
			back($a, "Adults please fill");
		} elseif (!is_numeric($_POST['kids'])) {
			back($a, "Kids please fill");
		} elseif (intval($_POST['adults']) + intval($_POST['kids']) == 0) {
			back($a, "Number of people cant be 0");
		} else {
			$_SESSION['checked_options']['people'] = intval($_POST['adults']) + intval($_POST['kids']);
			$_SESSION['checked_options']['adults'] = $_POST['adults'];
			$_SESSION['checked_options']['kids'] = $_POST['kids']; 
		}
	} else {
		if ($_SESSION['error'][0] == "existed_dates") {
			$kre = $_SESSION['error'][1];
			unset($_SESSION['error']);
		} else {
			header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
		}
	}
?>
<?php include 'head_layout.php'; ?>
<div class="section2">
	<i class="fa-solid fa-house home"></i>
	<form action="car_type.php" method="POST">
		<h1>Location</h1>
		<?php if (isset($kre)): ?>
			<p class="error"><?=$kre?></p>
		<?php endif ?>
		<div class="inputs_texts">
			<div class="inputt">
				<div class="label">Location from:</div>
				<div class="input"><input type="text" name="location" placeholder="Where we should take you" required></div>
			</div>
		</div>
		<div class="button">
			<button type="submit">Next<i class="fa-solid fa-angles-right"></i></button>
		</div>
	</form>
	<div class="back"><i class="fa-solid fa-angles-left"></i> Back</div>
</div>
</body>
<style type="text/css">
	div.inputt {
		width: 590px;
	}
</style>
<script type="text/javascript" src="../javascript/back.js"></script>
</html>

<!-- <form action="car_type.php" method="POST">
		Location:
		<input type="text" name="location" required>
		<button type="submit">Next</button>
	</form> -->