<?php 
	session_start();

	$a = "type";

	function back ($a, $b) {
		$_SESSION['error'] = [$a, $b];
		header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
	}

	if (isset($_POST['type'])) {
		if (!($_POST['type'] == "Group" or $_POST['type'] == "Individual")) {
			back($a, "Group or Individual should be");
		} elseif (!$_SESSION['tour_species']['cangroup'] and $_POST['type'] == "Group") {
			back($a, "This tour don't have group type");
		} else {
			$_SESSION['checked_options']['type'] = $_POST['type'];
		}
	} else {
		if ($_SESSION['error'][0] == "number_of_people") {
			$kre = $_SESSION['error'][1];
			unset($_SESSION['error']);
		} else {
			header("Location: ".$a.".php?tour_id=".$_SESSION['tour_species']['ID']);
		}
	}

	$url = $_SESSION['checked_options']['type'] == "Group" ? "existed_dates" : "location";
?>
<?php include 'head_layout.php'; ?>
	<div class="section2">
		<i class="fa-solid fa-house home"></i>
		<form action="<?=$url?>.php" method="POST">
			<h1>Number of people</h1>
			<?php if (isset($kre)): ?>
				<p class="error"><?=$kre?></p>
			<?php endif ?>
			<div class="inputs_texts">
				<div class="inputt">
					<div class="label">Adults:</div>
					<div class="input"><input type="number" name="adults" value="0" required></div>
				</div>
				<div class="inputt">
					<div class="label">Kids:</div>
					<div class="input"><input type="number" name="kids" value="0" required></div>
				</div>
			</div>
			<div class="button">
				<button type="submit">Next<i class="fa-solid fa-angles-right"></i></button>
			</div>
		</form>
		<div class="back"><i class="fa-solid fa-angles-left"></i> Back</div>
	</div>
</body>
<script type="text/javascript" src="../javascript/back.js"></script>
</html>