<!-- <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<style type="text/css">
		input {
			width: 300px;
		} #map {
			width: 500px;
			height: 500px;
		}
	</style>
	<script src="http://maps.googleapis.com/maps/api/js?libraries=places&sensor=false"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/geocomplete/1.7.0/jquery.geocomplete.min.js"></script>
</head>
<body>
	<input type="text">

	<div id="map"></div>

	<script type="text/javascript">
		$('input').geocomplete({
			map: "#map",
		});
	</script>
</body>
</html>


 -->

 <?php 
echo serialize([
    ['see', 'Every light in this city means a different story. Imagine yourself
                    witnessing each of them in the heart of two continents. This city will
                    look into your soul directly and make your experiences timeless.' ],
    ['taste', 'Tashkent is waiting for you with its unique tastes from bitter to
          sweet, sour to salty. Aside from its enchanting historical beauty,
          Tashkent is the right address even just to try new flavours!', 'taste_tashkent'],
    ['smell', 'The past, the present and the future full of surprises give this city
          its fragrance. You will find your childhood in a flower, the
          excitement of the future in a delicious meal, and the beauty of today
          in the unique scent of the forest, sea and streets in Tashkent.'],
    ['touch', 'Feel the texture of Tashkent in the details of an antique building, in
          the soft fur of a stray cat, in a tulip that fascinates with its
          color, or in an authentic silk fabric. Tashkent will touch you as you
          stroll through the streets of this city.'],
    ['listen', 'Listen to the heartbeats of two continents! If Tashkent was a playlist
          it would play in shuffle.'],
    ['routes', 'Every light in this city means a different story. Imagine yourself
          witnessing each of them in the heart of two continents. This city will
          look into your soul directly and make your experiences timeless.'],
    ['10 vibes from Tashkent', 'With its reservoirs that supplied İstanbul with water for many
          centuries after its foundation, its fountains, and rich fauna, today,
          Belgrad Forest serves as the city’s lungs. Roughly half an hour’s
          drive from the city center, Belgrad Forest’s running and cycling
          tracks make it a matchless destination for sports enthusiasts.'],
    ['48 hours', 'Straddling the Bosphorus Strait Asia, Tashkent is etched with
          thousands of years of history, bearing the marks of the Ancient
          Greeks, the Persians, the Romans, the Byzantines, the Uzbeks, and the
          Silk Road traders who`ve lived here over the centuries.']
]);
  ?>